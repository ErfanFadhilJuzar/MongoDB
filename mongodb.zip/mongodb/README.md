# MongoDB Community Edition Installation Guide

These documents provide instructions to install MongoDB Community Edition on various platforms.

## Install on Linux
Install MongoDB Community Edition and required dependencies on Linux.

🔗 [MongoDB Installation on Linux](https://www.mongodb.com/docs/manual/administration/install-on-linux/)

## Install on macOS
Install MongoDB Community Edition on macOS systems from MongoDB archives.

🔗 [MongoDB Installation on macOS](https://www.mongodb.com/docs/manual/tutorial/install-mongodb-on-os-x/)

## Install on Windows
Install MongoDB Community Edition on Windows systems and optionally start MongoDB as a Windows service.

🔗 [MongoDB Installation on Windows](https://www.mongodb.com/docs/manual/tutorial/install-mongodb-on-windows/)

## Install on Docker
Install a MongoDB Community Docker container.

🔗 [MongoDB Installation on Docker](https://www.mongodb.com/docs/manual/tutorial/install-mongodb-with-docker/)

## Install MongoDB Compass Download
Install a MongoDB Compass Download.

🔗 [MongoDB Compass Download](https://www.mongodb.com/try/download/compass)

---

## CREATE TABLE di MySQL
Create database name db_store in mysql

```sh
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` varchar(25) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `ram` varchar(50) DEFAULT NULL,
  `processor` varchar(100) DEFAULT NULL,
  `storage` varchar(100) DEFAULT NULL,
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags`)),
  `stock` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci
```

---

## Clone the Repository
To clone the MongoDB project repository, use the following command:

```sh
git clone https://gitlab.com/ysw/mongodb.git
cd mongodb
go mod init mongodb
go mod tidy
```

---

## Testing with cURL
You can test the API endpoints using `cURL` commands as follows:

### Create a Product
```sh
curl --location 'http://localhost:9090/product' \
--header 'Content-Type: application/json' \
--data '{
  "name": "Laptop ASUS ROG",
  "price": 25000000,
  "category": "Electronics",
  "specifications": {
    "RAM": "16GB",
    "Processor": "Intel i7",
    "Storage": "512GB SSD"
  },
  "tags": ["gaming", "laptop", "asus"],
  "stock": 10
}'
```

### Get All Products
```sh
curl --location 'http://localhost:9090/products'
```

### Get a Specific Product
```sh
curl --location 'http://localhost:9090/product/67dcc64901f4f6aadd6cc1b1'
```

### Update a Product
```sh
curl --location --request PUT 'http://localhost:9090/product/67dcc64901f4f6aadd6cc1b1' \
--header 'Content-Type: application/json' \
--data '{
  "_id": "67dcc64901f4f6aadd6cc1b1",
  "name": "Laptop ASUS ROG",
  "price": 29000000,
  "category": "Electronics",
  "specifications": {
    "RAM": "16GB",
    "Processor": "Intel i7",
    "Storage": "512GB SSD"
  },
  "tags": ["gaming", "laptop", "asus"],
  "stock": 10
}'
```

### Delete a Product
```sh
curl --location --request DELETE 'http://localhost:9090/product/67dcdc94e64d72769cf48713' \
--header 'Content-Type: application/json'
```

### Search Product
```sh
curl --location 'http://localhost:9090/search' \
--header 'Content-Type: application/json' \
--data '{
  "category": "Electronics",
  "price": { "$gte": 20000000, "$lte": 30000000 },
  "specifications.RAM": { "$in": ["16GB", "32GB"] }
}'
```

# MongoDB Compass GUI

Berikut adalah contoh query MongoDB yang dapat Anda jalankan di **MongoDB Compass** untuk berinteraksi dengan data di atas.

### **1️⃣ Menambahkan Data (Insert)**
Gunakan query **Insert One** untuk menambahkan data ke dalam koleksi **products**:

```json
db.products.insertOne({
  "_id": ObjectId("67dcc64901f4f6aadd6cc1b1"),
  "name": "Laptop ASUS ROG",
  "price": 29000000,
  "category": "Electronics",
  "specifications": {
    "RAM": "16GB",
    "Processor": "Intel i7",
    "Storage": "512GB SSD"
  },
  "tags": ["gaming", "laptop", "asus"],
  "stock": 10
})
```

---

### **2️⃣ Menampilkan Semua Data**
Menampilkan semua data dalam koleksi **products**:
```json
db.products.find({})
```

---

### **3️⃣ Mencari Berdasarkan Nama**
Menampilkan produk yang memiliki nama **Laptop ASUS ROG**:
```json
db.products.find({ "name": "Laptop ASUS ROG" })
```

---

### **4️⃣ Mencari Berdasarkan Kategori**
Menampilkan semua produk dalam kategori **Electronics**:
```json
db.products.find({ "category": "Electronics" })
```

---

### **5️⃣ Mencari Berdasarkan Tag**
Menampilkan produk yang memiliki tag `"gaming"`:
```json
db.products.find({ "tags": "gaming" })
```

---

### **6️⃣ Menampilkan Produk dengan Harga di Atas 25 Juta**
```json
db.products.find({ "price": { "$gt": 25000000 } })
```

---

### **7️⃣ Update Harga Produk**
Mengupdate harga produk **Laptop ASUS ROG** menjadi **Rp 27.000.000**:
```json
db.products.updateOne(
  { "_id": ObjectId("67dcc64901f4f6aadd6cc1b1") },
  { "$set": { "price": 27000000 } }
)
```

---

### **8️⃣ Menambah Stok Produk**
Menambah stok produk sebanyak 5 unit:
```json
db.products.updateOne(
  { "_id": ObjectId("67dcc64901f4f6aadd6cc1b1") },
  { "$inc": { "stock": 5 } }
)
```

---

### **9️⃣ Menghapus Produk**
Menghapus produk berdasarkan `_id`:
```json
db.products.deleteOne({ "_id": ObjectId("67dcc64901f4f6aadd6cc1b1") })
```

---

Dalam skenario **e-commerce**, pencarian sering kali lebih kompleks karena pengguna dapat mencari produk berdasarkan berbagai filter seperti **kategori**, **harga**, **rating**, **stok**, atau **spesifikasi tertentu**. Berikut adalah beberapa contoh **query kompleks** yang sering digunakan dalam aplikasi e-commerce menggunakan **MongoDB**:

---

## **1️⃣ Pencarian Produk dengan Banyak Filter**
Misalkan kita ingin mencari semua produk dalam kategori **Electronics**, dengan harga antara **Rp 20.000.000 - Rp 30.000.000**, serta memiliki **RAM minimal 16GB**:
```json
db.products.find({
  "category": "Electronics",
  "price": { "$gte": 20000000, "$lte": 30000000 },
  "specifications.RAM": { "$in": ["16GB", "32GB"] }
})
```
**Penjelasan**:
- **`category: "Electronics"`** → Produk hanya dalam kategori **Electronics**.
- **`price: { "$gte": 20000000, "$lte": 30000000 }`** → Harga di antara **20 juta hingga 30 juta**.
- **`specifications.RAM: { "$in": ["16GB", "32GB"] }`** → Hanya menampilkan laptop dengan **RAM 16GB atau 32GB**.

---

## **2️⃣ Pencarian dengan Kata Kunci (Full-Text Search)**
Jika pengguna mencari produk dengan kata kunci seperti **"ASUS"** atau **"ROG"**, kita bisa menggunakan **text search**:
```json
db.products.createIndex({ "name": "text", "tags": "text" }) // Buat indeks teks

db.products.find({ "$text": { "$search": "ASUS ROG" } })
```
**Penjelasan**:
- **`createIndex({ "name": "text", "tags": "text" })`** → Membuat **text index** pada `name` dan `tags` untuk pencarian cepat.
- **`{ "$text": { "$search": "ASUS ROG" } }`** → Mencari **ASUS ROG** di dalam `name` atau `tags`.

---

## **3️⃣ Sorting (Urutkan Berdasarkan Harga Terendah)**
Jika pengguna ingin melihat daftar produk dengan harga **termurah terlebih dahulu**, gunakan `sort()`:
```json
db.products.find({ "category": "Electronics" }).sort({ "price": 1 })
```
**Penjelasan**:
- **`sort({ "price": 1 })`** → Mengurutkan **dari harga termurah ke termahal**.
- **`sort({ "price": -1 })`** → Jika ingin **termahal ke termurah**.

---

## **4️⃣ Filter Produk yang Tersedia (Stock > 0)**
```json
db.products.find({ "stock": { "$gt": 0 } })
```
**Penjelasan**:
- **`stock: { "$gt": 0 }`** → Hanya menampilkan produk yang masih tersedia (**stok lebih dari 0**).

---

## **5️⃣ Pencarian Produk Berdasarkan Tags**
Jika pengguna mencari produk dengan tag **"gaming"** dan **"laptop"**:
```json
db.products.find({ "tags": { "$all": ["gaming", "laptop"] } })
```
**Penjelasan**:
- **`tags: { "$all": ["gaming", "laptop"] }`** → Hanya menampilkan produk yang memiliki **kedua tag tersebut**.

---

## **6️⃣ Pencarian Produk dengan Pagination (Limit & Skip)**
Dalam aplikasi e-commerce, kita sering menggunakan **pagination** agar tidak menampilkan semua produk sekaligus. Misalkan, kita ingin menampilkan **10 produk per halaman**, dan saat ini sedang di halaman **ke-2**:
```json
db.products.find({ "category": "Electronics" })
  .sort({ "price": 1 })
  .skip(10) // Lewati 10 produk pertama
  .limit(10) // Ambil 10 produk berikutnya
```
**Penjelasan**:
- **`skip(10)`** → Lewati **10 produk pertama** (halaman pertama).
- **`limit(10)`** → Ambil **10 produk berikutnya**.

---

## **7️⃣ Produk dengan Harga Diskon**
Jika kita ingin mencari produk yang sedang diskon (misalnya memiliki field `discount_price` yang lebih rendah dari `price`):
```json
db.products.find({
  "$expr": { "$lt": ["$discount_price", "$price"] }
})
```
**Penjelasan**:
- **`$expr`** → Digunakan untuk membandingkan dua field (`discount_price < price`).

---

## **8️⃣ Pencarian Produk dengan Rating Minimal 4.5**
Jika setiap produk memiliki **rating**, kita bisa mencari produk dengan **minimal rating 4.5**:
```json
db.products.find({ "rating": { "$gte": 4.5 } })
```
**Penjelasan**:
- **`rating: { "$gte": 4.5 }`** → Menampilkan hanya produk dengan **rating 4.5 atau lebih tinggi**.

---

## **Kesimpulan**
Dalam aplikasi **e-commerce**, kita sering menggunakan kombinasi **filter**, **sorting**, **pagination**, dan **text search** untuk menampilkan produk yang relevan. Jika skala data sangat besar, kita bisa:
1. **Gunakan indeks** (`createIndex()` pada kolom penting seperti `price`, `category`, `tags`).
2. **Gunakan aggregation** jika memerlukan query lebih kompleks.
3. **Gunakan Redis** untuk caching data produk yang sering diakses.

