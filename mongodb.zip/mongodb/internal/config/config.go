package config

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"time"

	_ "github.com/go-sql-driver/mysql"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var (
	MySQLDB *sql.DB
	MongoDB *mongo.Client
)

func InitDB() {
	var err error

	// MySQL connection
	MySQLDB, err = sql.Open("mysql", "root:@tcp(localhost:3306)/db_store")
	if err != nil {
		log.Fatal("Gagal koneksi ke MySQL:", err)
	}

	MySQLDB.SetMaxOpenConns(10)
	MySQLDB.SetMaxIdleConns(5)
	MySQLDB.SetConnMaxLifetime(time.Minute * 5)

	if err := MySQLDB.Ping(); err != nil {
		log.Fatal("MySQL tidak dapat diakses:", err)
	}

	fmt.Println("✅ Koneksi MySQL berhasil!")

	// MongoDB connection
	clientOptions := options.Client().ApplyURI("mongodb://8.215.73.55:27017")
	MongoDB, err = mongo.Connect(context.TODO(), clientOptions)
	if err != nil {
		log.Fatal("Gagal koneksi ke MongoDB:", err)
	}

	if err := MongoDB.Ping(context.TODO(), nil); err != nil {
		log.Fatal("MongoDB tidak dapat diakses:", err)
	}

	fmt.Println("✅ Koneksi MongoDB berhasil!")
}

func CloseDB() {
	MySQLDB.Close()
	MongoDB.Disconnect(context.TODO())
}
