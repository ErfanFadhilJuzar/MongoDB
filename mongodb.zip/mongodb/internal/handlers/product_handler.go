package handlers

import (
	"encoding/json"
	"github.com/gorilla/mux"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"mongodb/internal/models"
	repositories "mongodb/internal/repositories"
	"net/http"
)

func CreateProductEndpoint(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	var product models.Product
	if err := json.NewDecoder(r.Body).Decode(&product); err != nil {
		http.Error(w, `{"message": "Invalid request payload"}`, http.StatusBadRequest)
		return
	}

	product.ID = primitive.NewObjectID()
	if err := repositories.CreateProduct(product); err != nil {
		http.Error(w, `{"message": "`+err.Error()+`"}`, http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(product)
}

func GetProductsEndpoint(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	products, err := repositories.GetAllProducts()
	if err != nil {
		http.Error(w, `{"message": "`+err.Error()+`"}`, http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(products)
}

func GetProductEndpoint(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	params := mux.Vars(r)

	id, err := primitive.ObjectIDFromHex(params["id"])
	if err != nil {
		http.Error(w, `{"message": "Invalid ID format"}`, http.StatusBadRequest)
		return
	}

	product, err := repositories.GetProductByID(id)
	if err != nil {
		http.Error(w, `{"message": "Product not found"}`, http.StatusNotFound)
		return
	}

	json.NewEncoder(w).Encode(product)
}

func UpdateProductEndpoint(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	params := mux.Vars(r)
	productID := params["id"]

	var product models.Product
	if err := json.NewDecoder(r.Body).Decode(&product); err != nil {
		http.Error(w, `{"message": "Invalid request payload"}`, http.StatusBadRequest)
		return
	}

	if err := repositories.UpdateProduct(productID, product); err != nil {
		http.Error(w, `{"message": "`+err.Error()+`"}`, http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(product)
}

func DeleteProductEndpoint(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	params := mux.Vars(r)
	productID := params["id"]

	if err := repositories.DeleteProduct(productID); err != nil {
		http.Error(w, `{"message": "`+err.Error()+`"}`, http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(map[string]string{"message": "Product deleted"})
}

func SearchProductsEndpoint(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")

	var filter bson.M
	if err := json.NewDecoder(r.Body).Decode(&filter); err != nil {
		http.Error(w, `{"message": "Invalid request payload"}`, http.StatusBadRequest)
		return
	}

	products, err := repositories.SearchProducts(filter)
	if err != nil {
		http.Error(w, `{"message": "`+err.Error()+`"}`, http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(products)
}
