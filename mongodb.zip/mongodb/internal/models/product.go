package models

import "go.mongodb.org/mongo-driver/bson/primitive"

type Specifications struct {
	RAM       string `bson:"RAM" json:"RAM"`
	Processor string `bson:"Processor" json:"Processor"`
	Storage   string `bson:"Storage" json:"Storage"`
}

type Product struct {
	ID             primitive.ObjectID `bson:"_id,omitempty" json:"_id,omitempty"`
	Name           string             `bson:"name" json:"name"`
	Price          int                `bson:"price" json:"price"`
	Category       string             `bson:"category" json:"category"`
	Specifications Specifications     `bson:"specifications" json:"specifications"`
	Tags           []string           `bson:"tags" json:"tags"`
	Stock          int                `bson:"stock" json:"stock"`
}
