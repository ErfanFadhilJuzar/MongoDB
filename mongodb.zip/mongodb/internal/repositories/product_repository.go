package repositoriespackage

import (
	"context"
	"encoding/json"
	"errors"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"mongodb/internal/config"
	"mongodb/internal/models"
)

func CreateProduct(product models.Product) error {
	tagsJSON, err := json.Marshal(product.Tags)
	if err != nil {
		return err
	}

	query := `INSERT INTO products (product_id, name, price, category, ram, processor, storage, tags, stock) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
	_, err = config.MySQLDB.Exec(query, product.ID.Hex(), product.Name, product.Price, product.Category, product.Specifications.RAM, product.Specifications.Processor, product.Specifications.Storage, string(tagsJSON), product.Stock)
	if err != nil {
		return err
	}

	collection := config.MongoDB.Database("store").Collection("products")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	_, err = collection.InsertOne(ctx, product)
	return err
}

func GetAllProducts() ([]models.Product, error) {
	collection := config.MongoDB.Database("store").Collection("products")
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	cursor, err := collection.Find(ctx, bson.M{})
	if err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)

	var products []models.Product
	for cursor.Next(ctx) {
		var product models.Product
		cursor.Decode(&product)
		products = append(products, product)
	}

	return products, nil
}

func GetProductByID(id primitive.ObjectID) (models.Product, error) {
	collection := config.MongoDB.Database("store").Collection("products")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	var product models.Product
	err := collection.FindOne(ctx, bson.M{"_id": id}).Decode(&product)
	return product, err
}

func UpdateProduct(productID string, product models.Product) error {
	tagsJSON, err := json.Marshal(product.Tags)
	if err != nil {
		return err
	}

	query := `UPDATE products SET name=?, price=?, category=?, ram=?, processor=?, storage=?, tags=?, stock=? WHERE product_id=?`
	_, err = config.MySQLDB.Exec(query, product.Name, product.Price, product.Category, product.Specifications.RAM, product.Specifications.Processor, product.Specifications.Storage, string(tagsJSON), product.Stock, productID)
	if err != nil {
		return err
	}

	objectID, err := primitive.ObjectIDFromHex(productID)
	if err != nil {
		return err
	}

	collection := config.MongoDB.Database("store").Collection("products")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	update := bson.M{"$set": product}
	_, err = collection.UpdateOne(ctx, bson.M{"_id": objectID}, update)
	return err
}

func DeleteProduct(productID string) error {
	query := `DELETE FROM products WHERE product_id=?`
	_, err := config.MySQLDB.Exec(query, productID)
	if err != nil {
		return err
	}

	objectID, err := primitive.ObjectIDFromHex(productID)
	if err != nil {
		return err
	}

	collection := config.MongoDB.Database("store").Collection("products")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	_, err = collection.DeleteOne(ctx, bson.M{"_id": objectID})
	return err
}

func SearchProducts(filter bson.M) ([]models.Product, error) {
	collection := config.MongoDB.Database("store").Collection("products")
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	cursor, err := collection.Find(ctx, filter)
	if err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)

	var products []models.Product
	for cursor.Next(ctx) {
		var product models.Product
		if err := cursor.Decode(&product); err != nil {
			return nil, err
		}
		products = append(products, product)
	}

	if len(products) == 0 {
		return nil, errors.New("product not found")
	}

	return products, nil
}
