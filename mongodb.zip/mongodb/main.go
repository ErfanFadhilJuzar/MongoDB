package main

import (
	"log"
	"net/http"

	"github.com/gorilla/mux"
	"mongodb/internal/config"
	"mongodb/internal/handlers"
)

func main() {
	config.InitDB()
	defer config.CloseDB()

	router := mux.NewRouter()
	router.HandleFunc("/product", handlers.CreateProductEndpoint).Methods("POST")
	router.HandleFunc("/products", handlers.GetProductsEndpoint).Methods("GET")
	router.HandleFunc("/product/{id}", handlers.GetProductEndpoint).Methods("GET")
	router.HandleFunc("/product/{id}", handlers.UpdateProductEndpoint).Methods("PUT")
	router.HandleFunc("/product/{id}", handlers.DeleteProductEndpoint).Methods("DELETE")
	router.HandleFunc("/search", handlers.SearchProductsEndpoint).Methods("POST")

	log.Println("🚀 Server berjalan di port 9090...")
	log.Fatal(http.ListenAndServe(":9090", router))
}
